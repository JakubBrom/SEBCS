.. SEBCS documentation master file, created by
   sphinx-quickstart on Sun Feb 12 17:11:03 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SEBCS's documentation!
============================================

Contents:

.. toctree::
   :maxdepth: 2

   tutorial
   SEBCSlib


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

*** Tohle je nadpis***

Zkusíme něco z texu

.. math::
    :label: f1
    
    y = ax^2 + bx + c\\

.. math::
    :label: f2

    x = \frac{a}{b}\cdot\rho\cdot{c_p}

A tady už to pokračuje :math:`a^2 = \frac{a}{b}`, :math:`x = y\frac{c}{a}`
Lorem ipsum dol :eq:`f1` je první

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam,
quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo
consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse
cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non
proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem
ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor
incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis
nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat.
Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore
eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt
inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor
sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut
labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud
exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis
aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu
fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt
inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor
sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut  labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud
exercitation ull.

